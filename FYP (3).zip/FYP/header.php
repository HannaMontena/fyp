<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
}
/* Style the header */
.header {

 background-image: url('../assets/h1.jpg');
 background-repeat:no-repeat;
 background-position:center;
 float:center;
 padding: 250px;
 width:100%;
 text-align: center;
}

/* Style the header */
.header {
  background-color: black;
 
  text-align: center;
}
</style>
</head>
<body>

<div class="header">
</div>

</body>
</html>
