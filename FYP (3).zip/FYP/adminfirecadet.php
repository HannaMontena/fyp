<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<meta name="description" content="" />
<meta name="author" content="" />
<title>Admin Fire Cadets</title>
<link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
<script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
<link href="css/styles.css" rel="stylesheet" />
<script type="text/javascript">
function saveEdits9() {

var editElem9 = document.getElementById("edit9");

var userVersion9 = editElem9.innerHTML;

localStorage.userEdits9 = userVersion9;

document.getElementById("update").innerHTML="Edits saved!";

}
function checkEdits9() {

if(localStorage.userEdits9!=null)
document.getElementById("edit9").innerHTML = localStorage.userEdits9;
}

</script>
<style>
.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #2c3e50;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 20px;
  padding: 20px;
  width: 200px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}
.button1 {
  display: inline-block;
  border-radius: 4px;
  background-color: #2c3e50;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 20px;
  padding: 20px;
  width: 200px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}


.card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
 background-color:white;
 color:black;
  width: 60%;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

.container {
  padding: 2px 16px;
}
</style>
</head>

<body id="page-top" onload="checkEdits9()">
       
      <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
      <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top">MYCLUB SYSTEM</a>
      <button class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      Menu
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto">
      <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="adminannouncement.php">ANNOUNCEMENT</a></li>
      <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="adminpage.php">VIEW RECORD</a></li>
      <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="admincategory.php">CATEGORY</a></li>
	  <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="logout.php">LOGOUT</a></li>
      </ul>
      </div>
      </div>
      </nav>
	  
        <section class="page-section bg-primary text-white mb-0" id="about">
        <div class="container"><br><br>
         <h2 class="page-section-heading text-center text-uppercase text-white">VIEW RECORD FIRE CADETS</h2>
         <div class="divider-custom divider-light">
         <div class="divider-custom-line"></div>
         <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
         <div class="divider-custom-line"></div>
        </div>
		
	
       <div class="w3-center">
        </div>

      
      <img class="img-fluid" src="assets/img/portfolio/fcadet.jpg" alt="" /><div id="edit9" contenteditable="true">
      <p><h1>Our Goals !</h1><br>• Fire Cadets offers young people the opportunity to gain a real qualification, and develop their confidence and personal skills. It's a bit like Scouts or Guides – only you'll gain real-world skills, make lots of new friends, learn to work as a team, and have a lot of fun along the way.<br>
      
	  <hr>
	  
	 </br><h1>Activities</h1>
	  <p>1.General meeting of fire cadets<br>
		 2. Fire prevention/fire rescue competition/demonstration<br>
		 3. Foot marching guide<br>
		 4. A line of visiting fire cadets P.M.<br>
		 5. Rescue training from landslides/floods/road accidents<br>
		 6. Foot marching competition<br>
		 7. Bonding training/competition<br>
		 8. Poster painting competition<br>
		 9. First aid<br>
		10. Firefighting career talk<br>
		11.Camping guide<br>
		
		
		<hr>
	
	<br>
	
	<div class="card">
	<div class="container">
    <h4><b>En Kamarul</b></h4> 
    <p>Leader of Fire Cadet</p> 
	</div>
	</div><br>

	
	<div class="card">
	<div class="container">
    <h4><b>En Hairul</b></h4> 
    <p>Assistant Leader of Fire Cadet</p> 
	</div>
	</div>


<hr>
	</div><center><input type="button" class="button1" value="Save Edit" onclick="saveEdits9()"/><div id="update"></center><br></div></div>
    <center><a href="adminfirecadet1.php" class="button">View</a></center></div>
    </section>
	  
	   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
        <script src="assets/mail/jqBootstrapValidation.js"></script>
        <script src="assets/mail/contact_me.js"></script>
        <script src="js/scripts.js"></script>
	  
	  
</body>
</html>