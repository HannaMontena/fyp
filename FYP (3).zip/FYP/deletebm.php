<?php 
require('dblink.php');
$id=$_REQUEST['id'];
$query = "DELETE FROM bm WHERE id=$id";
$result = mysqli_query($conn,$query) or die ( mysqli_error());
header("Location: adminbahasamelayu1.php");
?>